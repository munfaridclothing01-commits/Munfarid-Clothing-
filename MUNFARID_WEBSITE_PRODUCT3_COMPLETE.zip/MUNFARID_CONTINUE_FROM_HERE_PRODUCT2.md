# MUNFARID CLOTHING WEBSITE — CONTINUE FROM HERE (PRODUCT 2 COMPLETE)

## IMPORTANT — CONTINUE, DO NOT RESTART
This is an existing Munfarid Clothing website project. Continue from the supplied website ZIP. Do NOT rebuild the website from zero and do NOT unnecessarily redesign it.

The ZIP in this handoff is the latest working project after Product 2 (BMW Inspired T-Shirt) was integrated.

## CURRENT WEBSITE DESIGN
- Premium luxury streetwear aesthetic
- Black / white / subtle grey
- Playfair Display + Inter typography
- Mobile-first
- Android-friendly
- Responsive
- Preserve existing navigation, footer, social links, WhatsApp button and all existing pages
- Do not change the established layout unless specifically required

## WEBSITE SECTIONS
- Home
- Products
- Collections
- About
- Contact
- Cart
- Terms & Conditions
- Help / Customer Support
- Footer: You Can Find Us
- Instagram / Facebook / TikTok
- Floating WhatsApp button

## OFFICIAL SOCIAL / CONTACT DETAILS
- Instagram: https://www.instagram.com/munfaridclothing
- Facebook: https://www.facebook.com/share/1EHoFn4PMG/
- TikTok: https://www.tiktok.com/@munfaridclothing
- WhatsApp: +92 371 2092414

## PRODUCT 1 — ALREADY INTEGRATED — DO NOT DISTURB
Name: Goku Inspired T-Shirt
Price: PKR 1,599

Existing images:
- assets/goku-front.jpg
- assets/goku-back.jpg
- assets/goku-front-model.jpg
- assets/goku-back-model.jpg

Product 1 already has its product detail page/gallery, description, features, print-quality section, Why You'll Love It section and Add to Cart functionality.

IMPORTANT: When adding future products, do not overwrite, remove, rename or alter Product 1 images, content or functionality unless explicitly requested.

## PRODUCT 2 — COMPLETED
Name: BMW Inspired T-Shirt
Price: PKR 1,399

Gallery images — ALL THREE BELONG TO ONE PRODUCT:
- assets/bmw-model-front.jpg
- assets/bmw-model-side.jpg
- assets/bmw-front.jpg

Product description:

BMW INSPIRED T-SHIRT

Minimal look. Premium feel. Built for those who love clean, bold streetwear.

Features:
- 200 GSM Dry-Fit Fabric
- Export Quality
- Premium & Comfortable Feel
- Breathable & Lightweight
- Oversized / Relaxed Look
- Color: Black
- Sizes: Medium & Large
- Price: Rs. 1,399/-

Limited pieces available. Upgrade your everyday fit with a clean BMW-inspired aesthetic.

DM us to order.

Product 2 must remain a single product with a multi-image gallery. Do NOT treat the three photos as separate products.

## PRODUCT 3 — COMPLETED
[LATEST] Name: Audi Inspired T-Shirt
Price: PKR 1,399

Gallery images — ALL THREE BELONG TO ONE PRODUCT:
- assets/audi-model-front.jpg
- assets/audi-model-side.jpg
- assets/audi-front.jpg

Product description:

MUNFARID — AUDI INSPIRED T-SHIRT

Audi Inspired Design | Premium Streetwear

Minimal look. Premium feel. Built for everyday street style.

Features:
- 200 GSM Premium Dry-Fit Fabric
- Premium Quality & Comfortable Feel
- Round Neck Design
- Regular/Fit Design
- Classic Black Color
- Available Sizes: Medium & Large
- Breathable & Lightweight Fabric
- Soft & Comfortable for Everyday Wear
- Clean, Premium Finish
- Unisex Streetwear Style

Limited Stock Available

Wear the attitude. Own the look. 🖤

MUNFARID — Built Different. Worn Different.

Product 3 is integrated as a single product with a three-image gallery. Product 1 and Product 2 remain unchanged.

## CURRENT ASSET LIST
- assets/goku-front.jpg
- assets/goku-back.jpg
- assets/goku-front-model.jpg
- assets/goku-back-model.jpg
- assets/bmw-model-front.jpg
- assets/bmw-model-side.jpg
- assets/bmw-front.jpg
- assets/munfarid-logo.jpg
- assets/placeholder.svg

## CURRENT WEBSITE FILES
- index.html
- products.html
- product.html
- collections.html
- about.html
- contact.html
- cart.html
- terms.html
- styles.css
- script.js
- assets/
- README.txt

## HOW PRODUCTS WORK
There are 4 main products in total.

Each product can have 4–5 photos showing different views. All photos sent together for one product are ONE product's gallery, not separate products.

When a customer opens a product, they should be able to swipe/click through that product's images.

The remaining workflow is:
1. User sends Product 3 photos (usually 4–5 photos together).
2. Treat all photos received together as ONE Product 3 gallery.
3. User sends Product 3 name, price and description.
4. Integrate Product 3 into the existing website without restarting or redesigning it.
5. Preserve Product 1 and Product 2.
6. Then repeat the same process for Product 4.

## IMPORTANT PRODUCT RULE
Do not assume that photos received in the same message are separate products. Unless the user explicitly says otherwise, 4–5 photos sent together are multiple views of ONE product.

## REMAINING WORK
- Product 4: photos + name + price + description
- Replace remaining placeholder product cards with the real products
- Ensure each product has its own gallery and product ID / equivalent clean implementation
- Later, replace collection placeholders when actual collection images/names are provided
- Check Home, Products, Collections and product detail pages on mobile
- Check cart behavior after all products are added
- Preserve social links, WhatsApp, footer, terms, support and navigation
- Eventually prepare the final project ZIP and exact GitHub/Vercel upload instructions

## NEXT MESSAGE FROM USER
The user is expected to continue from another device/ChatGPT account/session. They may upload Product 3 photos next.

If the user uploads Product 4 photos, immediately treat them as Product 4's gallery and wait for/accept the Product 4 name, price and description. Do not ask them to rebuild the project.

## HANDOFF INSTRUCTION
The user may upload this Markdown file together with the latest website ZIP to another ChatGPT session. The ZIP is the source of truth for the current website files, and this document explains the project state and continuation rules.
