
document.addEventListener("DOMContentLoaded",()=>{
  const menu=document.querySelector(".menu-btn"), nav=document.querySelector(".nav");
  if(menu) menu.addEventListener("click",()=>nav.classList.toggle("open"));

  let cart=JSON.parse(localStorage.getItem("munfarid-cart")||"[]");
  const save=()=>{localStorage.setItem("munfarid-cart",JSON.stringify(cart));updateCount();renderCart()};
  const updateCount=()=>document.querySelectorAll(".cart-count").forEach(e=>e.textContent=cart.length);
  document.querySelectorAll(".add-cart").forEach(btn=>btn.addEventListener("click",()=>{
    cart.push({name:btn.dataset.name,price:btn.dataset.price}); save(); btn.textContent="Added ✓";
    setTimeout(()=>btn.textContent="Add to Cart",1000);
  }));
  function renderCart(){
    const box=document.querySelector("#cart-items"), total=document.querySelector("#cart-total");
    if(!box) return;
    if(!cart.length){box.innerHTML="<p>Your cart is empty.</p>"; if(total) total.textContent="PKR 0"; return;}
    box.innerHTML=cart.map((x,i)=>`<div class="cart-row"><span>${x.name}</span><span>${x.price} <button data-remove="${i}" style="margin-left:12px;border:0;background:none;cursor:pointer">Remove</button></span></div>`).join("");
    box.querySelectorAll("[data-remove]").forEach(b=>b.onclick=()=>{cart.splice(+b.dataset.remove,1);save()});
    if(total) total.textContent="Items: "+cart.length;
  }
  updateCount(); renderCart();

  const slides=[...document.querySelectorAll(".slide")], dots=[...document.querySelectorAll(".dot")];
  if(slides.length){
    let i=0;
    const show=n=>{slides.forEach(s=>s.classList.remove("active"));dots.forEach(d=>d.classList.remove("active"));slides[n].classList.add("active");if(dots[n])dots[n].classList.add("active")};
    dots.forEach((d,n)=>d.onclick=()=>{i=n;show(i)});
    setInterval(()=>{i=(i+1)%slides.length;show(i)},5000);
  }
});
